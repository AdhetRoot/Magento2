<?php
namespace TresdTech\FinalProject\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $formKeyValidator;
    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory,\Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator)
    {
        $this->formKeyValidator = $formKeyValidator;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    

    public function execute()
    {
            //validando clave de formulario
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $resultPage = $this->_resultPageFactory->create();
            return $resultPage;

        }
    
 // Obteniendo los datos del formulario
 $data = $this->getRequest()->getPost();
 if(!empty($data)) {
     $firstname = $data['firstname'];
     $lastname = $data['lastname'];
     $email = $data['email'];
     $telephone = $data['telephone'];
     $form = $this->_objectManager->create('TresdTech\FinalProject\Model\Form');
     $form->setData('first_name', $firstname);
     $form->setData('last_name', $lastname);
     $form->setData('email', $email);
     $form->setData('telephone', $telephone);
     $form->save();
     $this->messageManager->addSuccessMessage(('Datos Guardados Correctamente.'));
 }
 $resultPage = $this->_resultPageFactory->create();
 return $resultPage;
}
}
?>
