<?php

namespace TresdTech\FinalProject\Model\ResourceModel;

class Form extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('finalProject', 'id');
    }
}
