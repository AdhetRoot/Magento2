<?php
namespace TresdTech\FinalProject\Model;

use Magento\Framework\Model\AbstractModel;

class FinalProject extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\TresdTech\FinalProject\Model\ResourceModel\FinalProject::class);
    }
}
