<?php

namespace TresdTech\FinalProject\Model;

class Form extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('TresdTech\FinalProject\Model\ResourceModel\Form');
    }
}