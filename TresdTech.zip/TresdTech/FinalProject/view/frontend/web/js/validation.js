require([
    'jquery',
    'jquery/ui',
    'jquery/validate'
], function ($) {
    $(document).ready(function () {
        console.log("validation.js is loaded")
        $('#form-id').validate({
            rules: {
                firstname: {
                    required: true,
                    alpha: true
                },
                lastname: {
                    required: true,
                    alpha: true
                },
                email: {
                    required: true,
                    email: true
                },
                telephone: {
                    required: true,
                    number: true
                }
            }
        });
    });
});
