<?php
namespace TresdTech\FinalProject\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}
